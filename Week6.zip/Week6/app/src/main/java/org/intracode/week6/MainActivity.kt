package org.intracode.week6

import android.content.Context
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val spinner = findViewById<Spinner>(R.id.spinner)
        val txtFullName = findViewById<EditText>(R.id.txtFullName)
        val txtEmail = findViewById<EditText>(R.id.txtEmail)
        val txtShow = findViewById<TextView>(R.id.txtShow)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val list = arrayOf ("Online", "TV", "Radio", "Other")
        val adapter1 = ArrayAdapter <String> (this, android.R.layout.simple_spinner_item, list)
        android.R.layout.simple_spinner_item
        android.R.layout.simple_spinner_dropdown_item
        spinner.adapter = adapter1
        btnSubmit.setOnClickListener{
            when (spinner.selectedItem.toString()){
                "Online" -> txtShow.text = "Name: ${txtFullName.text.toString()} Email ${txtEmail.text.toString()} How did you find us? Online"
                "TV" -> txtShow.text = "Name: ${txtFullName.text.toString()} Email ${txtEmail.text.toString()} How did you find us? TV"
                "Radio" -> txtShow.text = "Name: ${txtFullName.text.toString()} Email ${txtEmail.text.toString()} How did you find us? Radio"
                "Other" -> txtShow.text = "Name: ${txtFullName.text.toString()} Email ${txtEmail.text.toString()} How did you find us? Other"

            }
            hideKeyboard()
        }

        //Fire hidekeyboard when user taps outside any text object
//Place below code right before last right bracket in function onCreate
        findViewById<View>(android.R.id.content).setOnTouchListener { _, event ->
            hideKeyboard()
            false
        }
    }
    // function to hide keyboard goes right before the last right bracket of Class MainActivity
//import android.content.Context
//import android.view.inputmethod.InputMethodManager
    fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(currentFocus!!.windowToken, 0)
        } catch (e: Exception) {
            // TODO: handle exception
        }

    }
}